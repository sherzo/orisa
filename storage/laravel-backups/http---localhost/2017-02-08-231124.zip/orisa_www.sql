
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES (1,'Ver',NULL,NULL),(2,'Crear',NULL,NULL),(3,'Editar',NULL,NULL),(4,'Eliminar',NULL,NULL),(5,'Orden de compra',NULL,NULL),(6,'Procesar',NULL,NULL),(7,'Administrar',NULL,NULL);
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `assistances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assistances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `asistencia_id` int(10) unsigned NOT NULL,
  `hora_entrada` time NOT NULL,
  `hora_salida` time NOT NULL,
  `motivo` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `justificacion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assistances_empleado_id_foreign` (`empleado_id`),
  KEY `assistances_asistencia_id_foreign` (`asistencia_id`),
  CONSTRAINT `assistances_asistencia_id_foreign` FOREIGN KEY (`asistencia_id`) REFERENCES `days_with_assistances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assistances_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `assistances` WRITE;
/*!40000 ALTER TABLE `assistances` DISABLE KEYS */;
/*!40000 ALTER TABLE `assistances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `beverages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beverages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `trago` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` double(15,2) NOT NULL,
  `image_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `beverages_image_id_foreign` (`image_id`),
  CONSTRAINT `beverages_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `beverages` WRITE;
/*!40000 ALTER TABLE `beverages` DISABLE KEYS */;
INSERT INTO `beverages` VALUES (1,'Cuba libre','Bebida con alcohol',560.00,14,NULL,NULL),(2,'Mojito','Bebida con alcohol',400.00,15,NULL,NULL),(3,'Relative','Bebida con alcohol',350.00,16,NULL,NULL),(4,'Coctel','Bebida con alcohol',380.00,17,NULL,NULL),(5,'Naiguata','Bebida con alcohol',600.00,18,NULL,NULL),(6,'Vodka','Bebida con alcohol',500.00,19,NULL,NULL);
/*!40000 ALTER TABLE `beverages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `beverages_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beverages_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `beverage_id` int(10) unsigned NOT NULL,
  `ingredient_id` int(10) unsigned NOT NULL,
  `cantidad_ingrediente` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `beverages_has_ingredients_beverage_id_foreign` (`beverage_id`),
  KEY `beverages_has_ingredients_ingredient_id_foreign` (`ingredient_id`),
  KEY `beverages_has_ingredients_unit_id_foreign` (`unit_id`),
  CONSTRAINT `beverages_has_ingredients_beverage_id_foreign` FOREIGN KEY (`beverage_id`) REFERENCES `beverages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `beverages_has_ingredients_ingredient_id_foreign` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `beverages_has_ingredients_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `beverages_has_ingredients` WRITE;
/*!40000 ALTER TABLE `beverages_has_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `beverages_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `beverages_has_liqueurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beverages_has_liqueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `beverage_id` int(10) unsigned NOT NULL,
  `liqueur_id` int(10) unsigned NOT NULL,
  `cantidad_licor` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `beverages_has_liqueurs_beverage_id_foreign` (`beverage_id`),
  KEY `beverages_has_liqueurs_liqueur_id_foreign` (`liqueur_id`),
  KEY `beverages_has_liqueurs_unit_id_foreign` (`unit_id`),
  CONSTRAINT `beverages_has_liqueurs_beverage_id_foreign` FOREIGN KEY (`beverage_id`) REFERENCES `beverages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `beverages_has_liqueurs_liqueur_id_foreign` FOREIGN KEY (`liqueur_id`) REFERENCES `liqueurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `beverages_has_liqueurs_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `beverages_has_liqueurs` WRITE;
/*!40000 ALTER TABLE `beverages_has_liqueurs` DISABLE KEYS */;
INSERT INTO `beverages_has_liqueurs` VALUES (1,1,1,10.00,4,NULL,NULL),(2,2,1,20.00,4,NULL,NULL),(3,3,1,30.00,4,NULL,NULL),(4,4,1,40.00,4,NULL,NULL),(5,5,1,50.00,4,NULL,NULL),(6,6,1,60.00,4,NULL,NULL);
/*!40000 ALTER TABLE `beverages_has_liqueurs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `operacion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `operacion_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bitacora_user_id_foreign` (`user_id`),
  CONSTRAINT `bitacora_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cestaticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cestaticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unidad_tributaria` double(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cestaticket` WRITE;
/*!40000 ALTER TABLE `cestaticket` DISABLE KEYS */;
INSERT INTO `cestaticket` VALUES (1,177.00,12);
/*!40000 ALTER TABLE `cestaticket` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dni_cedula` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `operadora` int(11) NOT NULL,
  `telefono` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'regular',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_dni_cedula_unique` (`dni_cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'V-62846841','Waylon Cole','157 Nolan Mount\nWest Adrianna, MI 44088',6627,'70589582','regular',NULL,NULL),(2,'E-55773785','Odessa Abshire','5880 Gleason Union Suite 149\nPort London, MA 51896',101,'33824587','regular',NULL,NULL),(3,'V-167920511','Darian Kessler','92296 Wilton Terrace\nHomenickberg, HI 29674-0725',905,'12126453','regular',NULL,NULL),(4,'V-87684266','Kylie Haley','411 Rudy Garden Suite 855\nNorth Lilamouth, NJ 49934-7592',75563,'47783205','regular',NULL,NULL),(5,'V-157379486','Trinity Kuhic','95333 Clement Alley Apt. 861\nPort Thaddeus, VA 74482',238,'07350995','regular',NULL,NULL),(6,'V-155892876','Alycia Harvey','34722 Adeline Spring Apt. 339\nPort Delbert, NH 15999',1028,'98698404','regular',NULL,NULL),(7,'V-148618576','Baron Kihn','43971 Renner Lights\nNorth Dario, NY 56449',5220,'88831578','regular',NULL,NULL),(8,'E-141289719','Turner Prohaska','21433 Wiza Terrace\nOkunevamouth, ND 77699-2626',85450,'24492359','regular',NULL,NULL),(9,'V-40933261','Eleazar Jast','694 Werner Centers\nPort Lazaroview, MS 97437',255,'46283337','regular',NULL,NULL),(10,'E-153439521','Mohamed Mayert','93751 Lucinda Shoal\nNew Treyshire, AZ 12368-5498',49520,'38132065','regular',NULL,NULL),(11,'V-25607793','Saul','Calle 5 marzo #30-11',414,'5899312','regular',NULL,NULL),(12,'V-25607794','Cliente','Calle 5 marzo #30-11',414,'5899312','regular',NULL,NULL),(13,'V-25607795','Carlos','Calle 5 marzo #30-11',424,'5899312','regular',NULL,NULL);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estatus` varchar(20) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'En espera',
  `table_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commands_table_id_foreign` (`table_id`),
  KEY `commands_employee_id_foreign` (`employee_id`),
  CONSTRAINT `commands_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `commands_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commands` WRITE;
/*!40000 ALTER TABLE `commands` DISABLE KEYS */;
INSERT INTO `commands` VALUES (1,'Procesada',1,5,NULL,NULL),(2,'Procesada',1,5,NULL,NULL),(3,'Procesada',1,5,NULL,NULL),(4,'Procesada',1,5,NULL,NULL),(5,'Procesada',1,5,NULL,NULL),(6,'Procesada',1,5,NULL,NULL),(7,'Procesada',1,5,NULL,NULL),(8,'Procesada',1,5,NULL,NULL),(9,'Procesada',1,5,NULL,NULL),(10,'Procesada',1,5,NULL,NULL),(11,'Procesada',1,5,NULL,NULL),(12,'Procesada',1,5,NULL,NULL),(13,'Procesada',1,5,NULL,NULL),(14,'Procesada',1,5,NULL,NULL),(15,'Procesada',1,5,NULL,NULL),(16,'Procesada',1,5,NULL,NULL),(17,'Procesada',1,5,NULL,NULL),(18,'Procesada',1,5,NULL,NULL),(19,'Procesada',1,5,NULL,NULL);
/*!40000 ALTER TABLE `commands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commands_has_beverages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands_has_beverages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command_id` int(10) unsigned NOT NULL,
  `beverage_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commands_has_beverages_command_id_foreign` (`command_id`),
  KEY `commands_has_beverages_beverage_id_foreign` (`beverage_id`),
  CONSTRAINT `commands_has_beverages_beverage_id_foreign` FOREIGN KEY (`beverage_id`) REFERENCES `beverages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commands_has_beverages_command_id_foreign` FOREIGN KEY (`command_id`) REFERENCES `commands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commands_has_beverages` WRITE;
/*!40000 ALTER TABLE `commands_has_beverages` DISABLE KEYS */;
/*!40000 ALTER TABLE `commands_has_beverages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commands_has_drinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands_has_drinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command_id` int(10) unsigned NOT NULL,
  `drink_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commands_has_drinks_command_id_foreign` (`command_id`),
  KEY `commands_has_drinks_drink_id_foreign` (`drink_id`),
  CONSTRAINT `commands_has_drinks_command_id_foreign` FOREIGN KEY (`command_id`) REFERENCES `commands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commands_has_drinks_drink_id_foreign` FOREIGN KEY (`drink_id`) REFERENCES `drinks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commands_has_drinks` WRITE;
/*!40000 ALTER TABLE `commands_has_drinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `commands_has_drinks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commands_has_juices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands_has_juices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command_id` int(10) unsigned NOT NULL,
  `juice_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commands_has_juices_command_id_foreign` (`command_id`),
  KEY `commands_has_juices_juice_id_foreign` (`juice_id`),
  CONSTRAINT `commands_has_juices_command_id_foreign` FOREIGN KEY (`command_id`) REFERENCES `commands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commands_has_juices_juice_id_foreign` FOREIGN KEY (`juice_id`) REFERENCES `juices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commands_has_juices` WRITE;
/*!40000 ALTER TABLE `commands_has_juices` DISABLE KEYS */;
/*!40000 ALTER TABLE `commands_has_juices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commands_has_plates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands_has_plates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command_id` int(10) unsigned NOT NULL,
  `plate_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commands_has_plates_command_id_foreign` (`command_id`),
  KEY `commands_has_plates_plate_id_foreign` (`plate_id`),
  CONSTRAINT `commands_has_plates_command_id_foreign` FOREIGN KEY (`command_id`) REFERENCES `commands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commands_has_plates_plate_id_foreign` FOREIGN KEY (`plate_id`) REFERENCES `plates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commands_has_plates` WRITE;
/*!40000 ALTER TABLE `commands_has_plates` DISABLE KEYS */;
INSERT INTO `commands_has_plates` VALUES (1,1,1,0,NULL,NULL),(2,1,2,0,NULL,NULL),(3,1,3,0,NULL,NULL),(4,2,1,0,NULL,NULL),(5,2,2,0,NULL,NULL),(6,2,3,0,NULL,NULL),(7,3,1,0,NULL,NULL),(8,3,2,0,NULL,NULL),(9,3,3,0,NULL,NULL),(10,4,1,0,NULL,NULL),(11,4,2,0,NULL,NULL),(12,4,3,0,NULL,NULL),(13,5,1,0,NULL,NULL),(14,5,2,0,NULL,NULL),(15,5,3,0,NULL,NULL),(16,6,1,0,NULL,NULL),(17,6,2,0,NULL,NULL),(18,6,3,0,NULL,NULL),(19,7,1,0,NULL,NULL),(20,7,2,0,NULL,NULL),(21,7,3,0,NULL,NULL),(22,8,1,0,NULL,NULL),(23,8,2,0,NULL,NULL),(24,8,3,0,NULL,NULL),(25,9,1,0,NULL,NULL),(26,9,2,0,NULL,NULL),(27,9,3,0,NULL,NULL),(28,10,1,0,NULL,NULL),(29,10,2,0,NULL,NULL),(30,10,3,0,NULL,NULL),(31,11,1,0,NULL,NULL),(32,11,2,0,NULL,NULL),(33,11,3,0,NULL,NULL),(34,12,1,0,NULL,NULL),(35,12,2,0,NULL,NULL),(36,12,3,0,NULL,NULL),(37,13,1,0,NULL,NULL),(38,13,2,0,NULL,NULL),(39,13,3,0,NULL,NULL),(40,14,1,0,NULL,NULL),(41,14,2,0,NULL,NULL),(42,14,3,0,NULL,NULL),(43,15,1,0,NULL,NULL),(44,15,2,0,NULL,NULL),(45,15,3,0,NULL,NULL),(46,16,1,0,NULL,NULL),(47,16,2,0,NULL,NULL),(48,16,3,0,NULL,NULL),(49,17,1,0,NULL,NULL),(50,17,2,0,NULL,NULL),(51,17,3,0,NULL,NULL),(52,18,1,0,NULL,NULL),(53,18,2,0,NULL,NULL),(54,18,3,0,NULL,NULL),(55,19,1,0,NULL,NULL),(56,19,2,0,NULL,NULL),(57,19,3,0,NULL,NULL);
/*!40000 ALTER TABLE `commands_has_plates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `days_with_assistances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `days_with_assistances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `days_with_assistances_fecha_unique` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `days_with_assistances` WRITE;
/*!40000 ALTER TABLE `days_with_assistances` DISABLE KEYS */;
/*!40000 ALTER TABLE `days_with_assistances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ISLR` double(15,2) NOT NULL,
  `SSO` double(15,2) NOT NULL,
  `RPE` double(15,3) NOT NULL,
  `RPVH` double(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deductions` WRITE;
/*!40000 ALTER TABLE `deductions` DISABLE KEYS */;
INSERT INTO `deductions` VALUES (1,0.00,0.04,0.005,0.01,NULL,NULL);
/*!40000 ALTER TABLE `deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `drinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_unit` int(10) unsigned NOT NULL,
  `bebida` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `precio` double(15,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `caracteristica` text COLLATE utf8_spanish_ci NOT NULL,
  `stock_min` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drinks_id_unit_foreign` (`id_unit`),
  CONSTRAINT `drinks_id_unit_foreign` FOREIGN KEY (`id_unit`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `drinks` WRITE;
/*!40000 ALTER TABLE `drinks` DISABLE KEYS */;
INSERT INTO `drinks` VALUES (1,4,'Sonfil',500.00,0,'Naranja',20,NULL,NULL),(2,4,'Yukery',1200.00,0,'Naranja',20,NULL,NULL);
/*!40000 ALTER TABLE `drinks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employee_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_user_employee_id_foreign` (`employee_id`),
  KEY `employee_user_user_id_foreign` (`user_id`),
  CONSTRAINT `employee_user_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employee_user` WRITE;
/*!40000 ALTER TABLE `employee_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cargo_id` int(10) unsigned NOT NULL,
  `turno_id` int(10) unsigned NOT NULL,
  `dni_cedula` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `estado_civil` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `genero` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_dni_cedula_unique` (`dni_cedula`),
  KEY `employees_cargo_id_foreign` (`cargo_id`),
  KEY `employees_turno_id_foreign` (`turno_id`),
  CONSTRAINT `employees_cargo_id_foreign` FOREIGN KEY (`cargo_id`) REFERENCES `positions` (`id`),
  CONSTRAINT `employees_turno_id_foreign` FOREIGN KEY (`turno_id`) REFERENCES `turns` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,2,1,'V-11929804','Alysha','Walter','1993-06-10','Comprometido/a','5882 Adams Ridges\nTerryfurt, MO 05029-3632','1-877-395-8361','Masculino',NULL,NULL),(2,1,1,'V-80183360','Fabian','Kutch','2005-04-17','Casado/a','76809 Kling Underpass Suite 043\nSouth Idella, AR 10912-8494','800.532.4501','Masculino',NULL,NULL),(3,2,2,'E-76620082','Isabella','Becker','2016-01-25','Divorciado/a','13961 Mckayla Mall Suite 970\nSouth Salmamouth, MI 77669-1714','844.375.6556','Masculino',NULL,NULL),(4,2,1,'E-3495099','Ari','Stracke','2000-04-26','Soltero/a','38079 Schuster Flat Apt. 858\nSchroedershire, ID 28977','866-235-4566','Masculino',NULL,NULL),(5,2,1,'E-35087305','Adriel','Luettgen','1989-06-12','Divorciado/a','485 Mann Knoll Suite 582\nCrystelberg, AR 04344-2494','844.229.6681','Masculino',NULL,NULL),(6,1,1,'E-73058371','Jason','Wisoky','1983-06-06','Divorciado/a','13286 Conor Passage Suite 606\nWest Brandochester, SD 76778-5225','1-866-228-4243','Femenino',NULL,NULL),(7,2,1,'V-41299291','Kellen','Langworth','2015-08-30','Comprometido/a','4694 Kreiger Cliffs Apt. 413\nLake Delfina, IL 68482-9215','(866) 439-6355','Femenino',NULL,NULL),(8,2,2,'E-91004117','Henry','Medhurst','2009-11-30','Casado/a','849 Kemmer Freeway Suite 095\nLake Cortez, CA 70936','855-519-8271','Femenino',NULL,NULL),(9,1,2,'V-49998667','Pink','Dickens','2003-06-11','Soltero/a','664 Kayleigh Pines Apt. 408\nTurnershire, CA 54244-1788','1-844-506-2329','Masculino',NULL,NULL),(10,1,1,'V-81635397','Mabelle','Robel','2007-09-02','Comprometido/a','677 Shanie Cliffs\nLake Joshuashire, FL 86783-6947','888-589-7180','Masculino',NULL,NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees_has_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_has_days` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `dia_id` int(10) unsigned NOT NULL,
  `planificacion_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_has_days_empleado_id_foreign` (`empleado_id`),
  KEY `employees_has_days_dia_id_foreign` (`dia_id`),
  KEY `employees_has_days_planificacion_id_foreign` (`planificacion_id`),
  CONSTRAINT `employees_has_days_dia_id_foreign` FOREIGN KEY (`dia_id`) REFERENCES `plannings_has_days` (`id`),
  CONSTRAINT `employees_has_days_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `employees_has_days_planificacion_id_foreign` FOREIGN KEY (`planificacion_id`) REFERENCES `plannings` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees_has_days` WRITE;
/*!40000 ALTER TABLE `employees_has_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees_has_days` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees_has_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_has_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_has_users_empleado_id_foreign` (`empleado_id`),
  KEY `employees_has_users_usuario_id_foreign` (`usuario_id`),
  CONSTRAINT `employees_has_users_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employees_has_users_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees_has_users` WRITE;
/*!40000 ALTER TABLE `employees_has_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees_has_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extra_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extra_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `turno_id` int(10) unsigned NOT NULL,
  `valor_turno` double(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extra_hours_turno_id_foreign` (`turno_id`),
  CONSTRAINT `extra_hours_turno_id_foreign` FOREIGN KEY (`turno_id`) REFERENCES `turns` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extra_hours` WRITE;
/*!40000 ALTER TABLE `extra_hours` DISABLE KEYS */;
INSERT INTO `extra_hours` VALUES (1,1,300.00,NULL,NULL),(2,2,500.00,NULL,NULL);
/*!40000 ALTER TABLE `extra_hours` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imagen` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'1.jpg',NULL,NULL),(2,'2.jpg',NULL,NULL),(3,'3.jpg',NULL,NULL),(4,'4.jpg',NULL,NULL),(5,'5.jpg',NULL,NULL),(6,'6.jpg',NULL,NULL),(7,'7.jpg',NULL,NULL),(8,'8.jpg',NULL,NULL),(9,'9.jpg',NULL,NULL),(10,'10.jpg',NULL,NULL),(11,'11.jpg',NULL,NULL),(12,'12.jpg',NULL,NULL),(13,'13.jpg',NULL,NULL),(14,'14.jpg',NULL,NULL),(15,'15.jpg',NULL,NULL),(16,'16.jpg',NULL,NULL),(17,'17.jpg',NULL,NULL),(18,'18.jpg',NULL,NULL),(19,'19.jpg',NULL,NULL),(20,'20.jpg',NULL,NULL),(21,'21.jpg',NULL,NULL),(22,'22.jpg',NULL,NULL),(23,'23.jpg',NULL,NULL);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `info_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `codigo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_de_admision` date NOT NULL,
  `contrato` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `duracion` int(11) NOT NULL,
  `cestaticket` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `banco` varchar(35) COLLATE utf8_spanish_ci NOT NULL,
  `cuenta_tipo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `cuenta_numero` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `info_employees_codigo_unique` (`codigo`),
  UNIQUE KEY `info_employees_cuenta_numero_unique` (`cuenta_numero`),
  KEY `info_employees_empleado_id_foreign` (`empleado_id`),
  CONSTRAINT `info_employees_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `info_employees` WRITE;
/*!40000 ALTER TABLE `info_employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `info_employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_type` int(10) unsigned NOT NULL,
  `id_unit` int(10) unsigned NOT NULL,
  `ingrediente` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `stock` double(8,2) NOT NULL,
  `caracteristica` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `stock_min` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ingredients_id_type_foreign` (`id_type`),
  KEY `ingredients_id_unit_foreign` (`id_unit`),
  CONSTRAINT `ingredients_id_type_foreign` FOREIGN KEY (`id_type`) REFERENCES `ingredients_types` (`id`),
  CONSTRAINT `ingredients_id_unit_foreign` FOREIGN KEY (`id_unit`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
INSERT INTO `ingredients` VALUES (1,1,1,'Harina Pan',0.00,'Precocida',20,NULL,NULL),(2,4,4,'Maceite',0.00,'Aceite de soya',20,NULL,NULL);
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ingredients_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredients_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_ingrediente` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ingredients_types` WRITE;
/*!40000 ALTER TABLE `ingredients_types` DISABLE KEYS */;
INSERT INTO `ingredients_types` VALUES (1,'Harinas',NULL,NULL),(2,'Carnes',NULL,NULL),(3,'Frutas',NULL,NULL),(4,'Verduras',NULL,NULL),(5,'Legumbres',NULL,NULL),(6,'Condimentos',NULL,NULL);
/*!40000 ALTER TABLE `ingredients_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `command_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `subtotal` double(8,2) NOT NULL,
  `total` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoices_command_id_foreign` (`command_id`),
  KEY `invoices_client_id_foreign` (`client_id`),
  CONSTRAINT `invoices_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `invoices_command_id_foreign` FOREIGN KEY (`command_id`) REFERENCES `commands` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,1,4,13600.00,15912.00,NULL,NULL),(2,2,4,13600.00,15912.00,NULL,NULL),(3,3,4,13600.00,15912.00,NULL,NULL),(4,4,4,13600.00,15912.00,NULL,NULL),(5,5,4,13600.00,15912.00,NULL,NULL),(6,6,4,13600.00,15912.00,NULL,NULL),(7,7,4,13600.00,15912.00,NULL,NULL),(8,8,4,13600.00,15912.00,NULL,NULL),(9,9,4,13600.00,15912.00,NULL,NULL),(10,10,4,13600.00,15912.00,NULL,NULL),(11,11,4,13600.00,15912.00,NULL,NULL),(12,12,4,13600.00,15912.00,NULL,NULL),(13,13,4,13600.00,15912.00,NULL,NULL),(14,14,4,13600.00,15912.00,NULL,NULL),(15,15,4,13600.00,15912.00,NULL,NULL),(16,16,4,13600.00,15912.00,NULL,NULL),(17,17,4,13600.00,15912.00,NULL,NULL),(18,18,4,13600.00,15912.00,NULL,NULL),(19,19,4,13600.00,15912.00,NULL,NULL);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `iva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iva` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iva` double(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `iva` WRITE;
/*!40000 ALTER TABLE `iva` DISABLE KEYS */;
/*!40000 ALTER TABLE `iva` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `juices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `juices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jugo` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` double(10,2) NOT NULL,
  `image_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `juices_image_id_foreign` (`image_id`),
  CONSTRAINT `juices_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `juices` WRITE;
/*!40000 ALTER TABLE `juices` DISABLE KEYS */;
INSERT INTO `juices` VALUES (1,'Naranja','Jugos de naranja',500.00,20,NULL,NULL),(2,'Durazno','Jugo de duranzo',500.00,21,NULL,NULL),(3,'Parchita','Jugo de parchita',500.00,22,NULL,NULL),(4,'Lechoza','Jugo de lechoza',500.00,23,NULL,NULL);
/*!40000 ALTER TABLE `juices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `juices_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `juices_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `juice_id` int(10) unsigned NOT NULL,
  `ingredient_id` int(10) unsigned NOT NULL,
  `cantidad_ingrediente` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `juices_has_ingredients_juice_id_foreign` (`juice_id`),
  KEY `juices_has_ingredients_ingredient_id_foreign` (`ingredient_id`),
  KEY `juices_has_ingredients_unit_id_foreign` (`unit_id`),
  CONSTRAINT `juices_has_ingredients_ingredient_id_foreign` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `juices_has_ingredients_juice_id_foreign` FOREIGN KEY (`juice_id`) REFERENCES `juices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `juices_has_ingredients_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `juices_has_ingredients` WRITE;
/*!40000 ALTER TABLE `juices_has_ingredients` DISABLE KEYS */;
INSERT INTO `juices_has_ingredients` VALUES (1,1,1,10.00,2,NULL,NULL),(2,2,1,20.00,2,NULL,NULL),(3,3,1,30.00,2,NULL,NULL),(4,4,1,40.00,2,NULL,NULL);
/*!40000 ALTER TABLE `juices_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `liqueurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `id_unit` int(10) unsigned NOT NULL,
  `licor` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `stock` double(8,2) NOT NULL,
  `caracteristica` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `stock_min` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `liqueurs_type_id_foreign` (`type_id`),
  KEY `liqueurs_id_unit_foreign` (`id_unit`),
  CONSTRAINT `liqueurs_id_unit_foreign` FOREIGN KEY (`id_unit`) REFERENCES `units` (`id`),
  CONSTRAINT `liqueurs_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `liqueurs_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `liqueurs` WRITE;
/*!40000 ALTER TABLE `liqueurs` DISABLE KEYS */;
INSERT INTO `liqueurs` VALUES (1,1,4,'Carta roja',20.00,'Añejo',20,NULL,NULL),(2,1,4,'Cacique',0.00,'Añejo',20,NULL,NULL);
/*!40000 ALTER TABLE `liqueurs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `liqueurs_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liqueurs_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_licor` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `liqueurs_types` WRITE;
/*!40000 ALTER TABLE `liqueurs_types` DISABLE KEYS */;
INSERT INTO `liqueurs_types` VALUES (1,'Ron',NULL,NULL),(2,'Vino',NULL,NULL),(3,'Vodka',NULL,NULL),(4,'Whiskey',NULL,NULL),(5,'Brandi',NULL,NULL);
/*!40000 ALTER TABLE `liqueurs_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2015_09_05_212101_create_images_table',1),('2016_08_13_131538_create_roles_table',1),('2016_08_13_132148_create_users_table',1),('2016_08_13_133224_create_clients_table',1),('2016_08_13_134701_create_tables_table',1),('2016_08_13_134829_create_plates_table',1),('2016_08_13_134931_create_providers_table',1),('2016_08_13_135524_create_ingredients_types_table',1),('2016_08_13_135722_create_liqueurs_types_table',1),('2016_08_13_135833_create_turns_table',1),('2016_08_13_135835_create_positions_table',1),('2016_08_13_140121_create_employees_table',1),('2016_08_13_140558_create_info_employees_table',1),('2016_08_13_141008_create_units_table',1),('2016_08_13_141456_create_iva_table',1),('2016_08_13_141959_create_commands_table',1),('2016_08_13_142337_create_purchases_table',1),('2016_08_13_144216_create_liqueurs_table',1),('2016_08_13_144755_create_drinks_table',1),('2016_08_13_14476_create_beverages_table',1),('2016_08_13_145039_create_ingredients_table',1),('2016_08_13_145225_create_juices_table',1),('2016_08_13_145342_create_invoices_table',1),('2016_08_13_145831_create_commands_has_plates_table',1),('2016_08_13_145908_create_commands_has_drinks_table',1),('2016_08_13_150105_create_commands_has_juices_table',1),('2016_08_13_150106_create_commands_has_beverages',1),('2016_08_13_150518_create_plates_has_ingredients_table',1),('2016_08_13_150743_create_juices_has_ingredients_table',1),('2016_08_13_151940_create_purchases_has_ingredients_table',1),('2016_08_13_152342_create_purchases_has_drinks_table',1),('2016_08_13_152508_create_purchases_has_liqueurs_table',1),('2016_08_13_152651_create_providers_has_ingredients_table',1),('2016_08_13_152956_create_providers_has_drinks_table',1),('2016_08_13_153222_create_providers_has_liqueurs_table',1),('2016_08_13_154012_create_plannings_table',1),('2016_08_13_154254_create_extra_hours_table',1),('2016_08_13_154349_create_plannings_has_days_table',1),('2016_08_13_154437_create_deductions_table',1),('2016_08_13_154501_create_others_deductions_table',1),('2016_08_13_154502_create_others_assignments_table',1),('2016_08_13_154549_create_days_with_assistances_table',1),('2016_08_13_154550_create_assistances_table',1),('2016_08_14_144144_create_records_table',1),('2016_08_25_184556_create_employees_has_days_table',1),('2016_08_25_184628_create_employees_has_users_table',1),('2016_09_11_195000_create_sauces_table',1),('2016_09_11_195111_create_sauces_has_ingredients_table',1),('2016_09_14_133728_create_plates_has_sauces_table',1),('2016_09_19_115953_create_modules_table',1),('2016_09_19_120008_create_actions_table',1),('2016_09_19_120100_create_modules_has_actions_table',1),('2016_09_19_120133_create_users_modules_actions_table',1),('2016_09_25_114329_create_users_vip',1),('2016_09_25_120020_create_reservations_table',1),('2016_09_25_174639_create_payrolls_made_table',1),('2016_09_25_174942_create_payrolls_saved_table',1),('2016_09_25_175141_create_payrolls_table',1),('2016_10_03_185238_create_beverages_has_liqueurs',1),('2016_10_03_214320_create_beverages_has_ingredients',1),('2016_11_17_211717_create_payroll_deductions_table',1),('2016_11_18_091241_create_payrolls_assignments_table',1),('2016_11_19_190956_create_payrolls_deductions_table',1),('2016_11_20_165553_create_temporary_assignments_table',1),('2016_11_20_165603_create_temporary_deductions_table',1),('2016_11_21_135047_create_plates_has_liqueurs_table',1),('2016_11_25_081645_create_portals_table',1),('2016_11_25_081854_create_portal_plate_table',1),('2016_11_28_190142_create_cestaticket_table',1),('2016_11_29_213134_create_employee_user_table',1),('2016_11_30_115719_create_bitacora_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modulo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'Clientes',NULL,NULL),(2,'Platos',NULL,NULL),(3,'Bebidas',NULL,NULL),(4,'Jugos',NULL,NULL),(5,'Salsas',NULL,NULL),(6,'Comandas',NULL,NULL),(7,'Recibos',NULL,NULL),(8,'Reservacion',NULL,NULL),(9,'Asistencias',NULL,NULL),(10,'Cargos',NULL,NULL),(11,'Personal',NULL,NULL),(12,'Fechas',NULL,NULL),(13,'Dias',NULL,NULL),(14,'Planificacion',NULL,NULL),(15,'Orden de compra',NULL,NULL),(16,'Inventario',NULL,NULL),(17,'Proveedores',NULL,NULL),(18,'Ingredientes',NULL,NULL),(19,'Licores',NULL,NULL),(20,'Usuarios',NULL,NULL),(21,'Respaldo BD',NULL,NULL),(22,'Restauracion',NULL,NULL),(23,'Bitacora',NULL,NULL);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modules_has_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules_has_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modules_has_actions_module_id_foreign` (`module_id`),
  KEY `modules_has_actions_action_id_foreign` (`action_id`),
  CONSTRAINT `modules_has_actions_action_id_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `modules_has_actions_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modules_has_actions` WRITE;
/*!40000 ALTER TABLE `modules_has_actions` DISABLE KEYS */;
INSERT INTO `modules_has_actions` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,2,1,NULL,NULL),(6,2,2,NULL,NULL),(7,2,3,NULL,NULL),(8,2,4,NULL,NULL),(9,3,1,NULL,NULL),(10,3,2,NULL,NULL),(11,3,3,NULL,NULL),(12,3,4,NULL,NULL),(13,4,1,NULL,NULL),(14,4,2,NULL,NULL),(15,4,3,NULL,NULL),(16,4,4,NULL,NULL),(17,5,1,NULL,NULL),(18,5,2,NULL,NULL),(19,5,3,NULL,NULL),(20,5,4,NULL,NULL),(21,6,1,NULL,NULL),(22,6,2,NULL,NULL),(23,6,3,NULL,NULL),(24,6,4,NULL,NULL),(25,7,1,NULL,NULL),(26,7,2,NULL,NULL),(27,8,1,NULL,NULL),(28,8,2,NULL,NULL),(29,8,3,NULL,NULL),(30,8,4,NULL,NULL),(31,9,1,NULL,NULL),(32,9,2,NULL,NULL),(33,9,3,NULL,NULL),(34,9,4,NULL,NULL),(35,10,1,NULL,NULL),(36,10,2,NULL,NULL),(37,10,3,NULL,NULL),(38,10,4,NULL,NULL),(39,11,1,NULL,NULL),(40,11,2,NULL,NULL),(41,11,3,NULL,NULL),(42,11,4,NULL,NULL),(43,12,2,NULL,NULL),(44,12,4,NULL,NULL),(45,12,7,NULL,NULL),(46,13,3,NULL,NULL),(47,14,1,NULL,NULL),(48,14,2,NULL,NULL),(49,14,3,NULL,NULL),(50,14,4,NULL,NULL),(51,15,1,NULL,NULL),(52,15,2,NULL,NULL),(53,15,3,NULL,NULL),(54,15,4,NULL,NULL),(55,15,6,NULL,NULL),(56,16,1,NULL,NULL),(57,16,2,NULL,NULL),(58,16,3,NULL,NULL),(59,16,4,NULL,NULL),(60,17,1,NULL,NULL),(61,17,2,NULL,NULL),(62,17,3,NULL,NULL),(63,17,4,NULL,NULL),(64,17,5,NULL,NULL),(65,18,1,NULL,NULL),(66,18,2,NULL,NULL),(67,18,3,NULL,NULL),(68,18,4,NULL,NULL),(69,19,1,NULL,NULL),(70,19,2,NULL,NULL),(71,19,3,NULL,NULL),(72,19,4,NULL,NULL),(73,20,1,NULL,NULL),(74,20,2,NULL,NULL),(75,20,3,NULL,NULL),(76,20,4,NULL,NULL),(77,21,1,NULL,NULL),(78,22,1,NULL,NULL),(79,23,4,NULL,NULL);
/*!40000 ALTER TABLE `modules_has_actions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `others_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `others_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `valor` double(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `others_assignments` WRITE;
/*!40000 ALTER TABLE `others_assignments` DISABLE KEYS */;
INSERT INTO `others_assignments` VALUES (1,'ASFASFASFA',300.00,'2017-02-02 03:38:04','2017-02-02 03:38:04');
/*!40000 ALTER TABLE `others_assignments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `others_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `others_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `valor` double(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `others_deductions` WRITE;
/*!40000 ALTER TABLE `others_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `others_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payroll_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomina_id` int(10) unsigned NOT NULL,
  `deduccionesExtras_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_deductions_nomina_id_foreign` (`nomina_id`),
  KEY `payroll_deductions_deduccionesextras_id_foreign` (`deduccionesExtras_id`),
  CONSTRAINT `payroll_deductions_deduccionesextras_id_foreign` FOREIGN KEY (`deduccionesExtras_id`) REFERENCES `others_deductions` (`id`),
  CONSTRAINT `payroll_deductions_nomina_id_foreign` FOREIGN KEY (`nomina_id`) REFERENCES `payrolls_made` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payroll_deductions` WRITE;
/*!40000 ALTER TABLE `payroll_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nominasaved_id` int(10) unsigned NOT NULL,
  `nominamade_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_nominasaved_id_foreign` (`nominasaved_id`),
  KEY `payrolls_nominamade_id_foreign` (`nominamade_id`),
  CONSTRAINT `payrolls_nominamade_id_foreign` FOREIGN KEY (`nominamade_id`) REFERENCES `payrolls_made` (`id`),
  CONSTRAINT `payrolls_nominasaved_id_foreign` FOREIGN KEY (`nominasaved_id`) REFERENCES `payrolls_saved` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomina_id` int(10) unsigned NOT NULL,
  `asignacionesExtras_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_assignments_nomina_id_foreign` (`nomina_id`),
  KEY `payrolls_assignments_asignacionesextras_id_foreign` (`asignacionesExtras_id`),
  CONSTRAINT `payrolls_assignments_asignacionesextras_id_foreign` FOREIGN KEY (`asignacionesExtras_id`) REFERENCES `others_assignments` (`id`),
  CONSTRAINT `payrolls_assignments_nomina_id_foreign` FOREIGN KEY (`nomina_id`) REFERENCES `payrolls_made` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls_assignments` WRITE;
/*!40000 ALTER TABLE `payrolls_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls_assignments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomina_id` int(10) unsigned NOT NULL,
  `deducciones_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_deductions_nomina_id_foreign` (`nomina_id`),
  KEY `payrolls_deductions_deducciones_id_foreign` (`deducciones_id`),
  CONSTRAINT `payrolls_deductions_deducciones_id_foreign` FOREIGN KEY (`deducciones_id`) REFERENCES `deductions` (`id`),
  CONSTRAINT `payrolls_deductions_nomina_id_foreign` FOREIGN KEY (`nomina_id`) REFERENCES `payrolls_made` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls_deductions` WRITE;
/*!40000 ALTER TABLE `payrolls_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls_made`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls_made` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `cedula` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_completo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `cargo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `salario_d` double(8,2) NOT NULL,
  `salario_m` double(8,2) NOT NULL,
  `asignaciones_ext` double(20,2) NOT NULL,
  `deducciones_ext` double(20,2) NOT NULL,
  `islr` double(8,2) NOT NULL,
  `sso` double(8,2) NOT NULL,
  `rpe` double(8,2) NOT NULL,
  `rpvh` double(8,2) NOT NULL,
  `laborados` int(11) NOT NULL,
  `no_laborados` int(11) NOT NULL,
  `cestaticket` double(20,2) NOT NULL,
  `cestaticket_des` double(20,2) NOT NULL,
  `salario_total` double(20,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_made_usuario_id_foreign` (`usuario_id`),
  CONSTRAINT `payrolls_made_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls_made` WRITE;
/*!40000 ALTER TABLE `payrolls_made` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls_made` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payrolls_saved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls_saved` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mes` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `quincena` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payrolls_saved` WRITE;
/*!40000 ALTER TABLE `payrolls_saved` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls_saved` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plannings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plannings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_inicio` date NOT NULL,
  `fecha_final` date NOT NULL,
  `fechas` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estatus` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plannings` WRITE;
/*!40000 ALTER TABLE `plannings` DISABLE KEYS */;
INSERT INTO `plannings` VALUES (1,'1994-12-09','2017-11-10','1994-12-09 - 2017-11-10','Creada','2017-02-02 03:41:52','2017-02-02 03:41:52'),(2,'2017-02-01','2017-02-15','2017-02-01 - 2017-02-15','Creada','2017-02-02 03:42:38','2017-02-02 03:42:38');
/*!40000 ALTER TABLE `plannings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plannings_has_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plannings_has_days` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `planificacion_id` int(10) unsigned NOT NULL,
  `dia` date NOT NULL,
  `estatus` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `detalle` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plannings_has_days_planificacion_id_foreign` (`planificacion_id`),
  CONSTRAINT `plannings_has_days_planificacion_id_foreign` FOREIGN KEY (`planificacion_id`) REFERENCES `plannings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plannings_has_days` WRITE;
/*!40000 ALTER TABLE `plannings_has_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `plannings_has_days` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plate_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plate_portal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plate_id` int(10) unsigned NOT NULL,
  `portal_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plate_portal_plate_id_foreign` (`plate_id`),
  KEY `plate_portal_portal_id_foreign` (`portal_id`),
  CONSTRAINT `plate_portal_plate_id_foreign` FOREIGN KEY (`plate_id`) REFERENCES `plates` (`id`),
  CONSTRAINT `plate_portal_portal_id_foreign` FOREIGN KEY (`portal_id`) REFERENCES `portals` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plate_portal` WRITE;
/*!40000 ALTER TABLE `plate_portal` DISABLE KEYS */;
INSERT INTO `plate_portal` VALUES (1,1,1,NULL,NULL),(2,2,1,NULL,NULL),(3,3,1,NULL,NULL),(4,4,1,NULL,NULL),(5,5,1,NULL,NULL),(6,6,1,NULL,NULL);
/*!40000 ALTER TABLE `plate_portal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plato` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` double(15,2) NOT NULL,
  `image_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plates_image_id_foreign` (`image_id`),
  CONSTRAINT `plates_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plates` WRITE;
/*!40000 ALTER TABLE `plates` DISABLE KEYS */;
INSERT INTO `plates` VALUES (1,'Arroz','Plato de arroz con abichuela',3200.00,1,NULL,NULL),(2,'Asado','Plato de arroz con abichuela',3900.00,2,NULL,NULL),(3,'Bistec','Plato de arroz con abichuela',3500.00,3,NULL,NULL),(4,'Boloña','Plato de arroz con abichuela',3000.00,4,NULL,NULL),(5,'Caraota','Plato de arroz con abichuela',3500.00,5,NULL,NULL),(6,'Crouse','Plato de arroz con abichuela',4600.00,6,NULL,NULL),(7,'Espagueti','Plato de arroz con abichuela',4000.00,7,NULL,NULL),(8,'Tarta','Plato de arroz con abichuela',2900.00,8,NULL,NULL),(9,'Parrilla','Plato de arroz con abichuela',4500.00,9,NULL,NULL),(10,'Pasticho','Plato de arroz con abichuela',4300.00,10,NULL,NULL),(11,'Pollo','Plato de arroz con abichuela',4500.00,11,NULL,NULL),(12,'Pechuga','Plato de arroz con abichuela',4500.00,12,NULL,NULL),(13,'Tequeños','Plato de arroz con abichuela',1900.00,13,NULL,NULL);
/*!40000 ALTER TABLE `plates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plates_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plates_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plato_id` int(10) unsigned NOT NULL,
  `ingrediente_id` int(10) unsigned NOT NULL,
  `cantidad_ingrediente` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plates_has_ingredients_plato_id_foreign` (`plato_id`),
  KEY `plates_has_ingredients_ingrediente_id_foreign` (`ingrediente_id`),
  KEY `plates_has_ingredients_unit_id_foreign` (`unit_id`),
  CONSTRAINT `plates_has_ingredients_ingrediente_id_foreign` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plates_has_ingredients_plato_id_foreign` FOREIGN KEY (`plato_id`) REFERENCES `plates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plates_has_ingredients_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plates_has_ingredients` WRITE;
/*!40000 ALTER TABLE `plates_has_ingredients` DISABLE KEYS */;
INSERT INTO `plates_has_ingredients` VALUES (1,1,1,10.00,2,NULL,NULL),(2,2,1,20.00,2,NULL,NULL),(3,3,1,30.00,2,NULL,NULL),(4,4,1,40.00,2,NULL,NULL),(5,5,1,50.00,2,NULL,NULL),(6,6,1,60.00,2,NULL,NULL),(7,7,1,70.00,2,NULL,NULL),(8,8,1,80.00,2,NULL,NULL),(9,9,1,90.00,2,NULL,NULL),(10,10,1,100.00,2,NULL,NULL),(11,11,1,110.00,2,NULL,NULL),(12,12,1,120.00,2,NULL,NULL),(13,13,1,130.00,2,NULL,NULL);
/*!40000 ALTER TABLE `plates_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plates_has_liqueurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plates_has_liqueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plate_id` int(10) unsigned NOT NULL,
  `liqueur_id` int(10) unsigned NOT NULL,
  `cantidad_licor` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plates_has_liqueurs_plate_id_foreign` (`plate_id`),
  KEY `plates_has_liqueurs_liqueur_id_foreign` (`liqueur_id`),
  KEY `plates_has_liqueurs_unit_id_foreign` (`unit_id`),
  CONSTRAINT `plates_has_liqueurs_liqueur_id_foreign` FOREIGN KEY (`liqueur_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plates_has_liqueurs_plate_id_foreign` FOREIGN KEY (`plate_id`) REFERENCES `plates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plates_has_liqueurs_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plates_has_liqueurs` WRITE;
/*!40000 ALTER TABLE `plates_has_liqueurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `plates_has_liqueurs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plates_has_sauces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plates_has_sauces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salsa_id` int(10) unsigned NOT NULL,
  `plato_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plates_has_sauces_salsa_id_foreign` (`salsa_id`),
  KEY `plates_has_sauces_plato_id_foreign` (`plato_id`),
  CONSTRAINT `plates_has_sauces_plato_id_foreign` FOREIGN KEY (`plato_id`) REFERENCES `plates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plates_has_sauces_salsa_id_foreign` FOREIGN KEY (`salsa_id`) REFERENCES `sauces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plates_has_sauces` WRITE;
/*!40000 ALTER TABLE `plates_has_sauces` DISABLE KEYS */;
/*!40000 ALTER TABLE `plates_has_sauces` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `portals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estatus` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `portals` WRITE;
/*!40000 ALTER TABLE `portals` DISABLE KEYS */;
INSERT INTO `portals` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `portals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `salario` double(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'T95478','Chef',15000.00,NULL,NULL),(2,'X21501','Mesonero',12000.00,NULL,NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `operadora` int(11) NOT NULL,
  `telefono` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `providers_correo_unique` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'J-00006372-9','Alimentos Polar Comercial, C.A','Turmero, Aragua',800,'3728242','carola.valdivia@fundacionempre',NULL,NULL),(2,'J-00032569-3','C.A. Ron Santa teresa','El consejo',800,'4002598','info@fundacionsantateresa.org',NULL,NULL),(3,'J-72439469','Gladyce','695 Douglas Mall\nWest Ezekiel, AR 66427-9135',412,'05770946','jermaine.pollich@schmitt.com',NULL,NULL),(4,'G-90595962','Russel','61305 Ernestina Prairie Suite 090\nMarianport, WA 65488',412,'12833094','francis00@mcdermott.com',NULL,NULL),(5,'C-62585957','Alvina','8717 Breitenberg Dam\nBarrettview, MS 80917-0951',412,'60298982','macy31@haag.com',NULL,NULL),(6,'C-34396799','Delta','4652 Valerie Highway Apt. 192\nPort Staceyville, NJ 64568-7931',412,'59804307','florencio.bartell@gmail.com',NULL,NULL),(7,'J-106639898','Maximillia','219 Elsa Estates Apt. 805\nJedediahhaven, OH 93223-2991',412,'81716173','wjohnson@reichel.org',NULL,NULL),(8,'J-58732775','Zula','100 Ardella Shoal Suite 592\nSkilesside, MS 11337-4861',412,'45540174','larue49@mayert.info',NULL,NULL),(9,'C-32806609','London','32187 Deckow Lights\nPort Riley, AR 21532-1701',412,'16348530','jaleel77@hilpert.org',NULL,NULL);
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `providers_has_drinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers_has_drinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bebida_id` int(10) unsigned NOT NULL,
  `proveedor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `providers_has_drinks_bebida_id_foreign` (`bebida_id`),
  KEY `providers_has_drinks_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `providers_has_drinks_bebida_id_foreign` FOREIGN KEY (`bebida_id`) REFERENCES `drinks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `providers_has_drinks_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `providers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `providers_has_drinks` WRITE;
/*!40000 ALTER TABLE `providers_has_drinks` DISABLE KEYS */;
INSERT INTO `providers_has_drinks` VALUES (1,1,1),(2,1,2),(3,2,1),(4,2,2);
/*!40000 ALTER TABLE `providers_has_drinks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `providers_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ingrediente_id` int(10) unsigned NOT NULL,
  `proveedor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `providers_has_ingredients_ingrediente_id_foreign` (`ingrediente_id`),
  KEY `providers_has_ingredients_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `providers_has_ingredients_ingrediente_id_foreign` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `providers_has_ingredients_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `providers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `providers_has_ingredients` WRITE;
/*!40000 ALTER TABLE `providers_has_ingredients` DISABLE KEYS */;
INSERT INTO `providers_has_ingredients` VALUES (1,1,1),(2,1,2),(3,2,1),(4,2,2);
/*!40000 ALTER TABLE `providers_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `providers_has_liqueurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers_has_liqueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `licor_id` int(10) unsigned NOT NULL,
  `proveedor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `providers_has_liqueurs_licor_id_foreign` (`licor_id`),
  KEY `providers_has_liqueurs_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `providers_has_liqueurs_licor_id_foreign` FOREIGN KEY (`licor_id`) REFERENCES `liqueurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `providers_has_liqueurs_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `providers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `providers_has_liqueurs` WRITE;
/*!40000 ALTER TABLE `providers_has_liqueurs` DISABLE KEYS */;
INSERT INTO `providers_has_liqueurs` VALUES (1,1,1),(2,1,2),(3,2,1),(4,2,2);
/*!40000 ALTER TABLE `providers_has_liqueurs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(10) unsigned NOT NULL,
  `estatus` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `purchases_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `providers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchases_has_drinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases_has_drinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bebida_id` int(10) unsigned NOT NULL,
  `compra_id` int(10) unsigned NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_has_drinks_bebida_id_foreign` (`bebida_id`),
  KEY `purchases_has_drinks_compra_id_foreign` (`compra_id`),
  CONSTRAINT `purchases_has_drinks_bebida_id_foreign` FOREIGN KEY (`bebida_id`) REFERENCES `drinks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchases_has_drinks_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchases_has_drinks` WRITE;
/*!40000 ALTER TABLE `purchases_has_drinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases_has_drinks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchases_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ingrediente_id` int(10) unsigned NOT NULL,
  `compra_id` int(10) unsigned NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_has_ingredients_ingrediente_id_foreign` (`ingrediente_id`),
  KEY `purchases_has_ingredients_compra_id_foreign` (`compra_id`),
  CONSTRAINT `purchases_has_ingredients_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchases_has_ingredients_ingrediente_id_foreign` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchases_has_ingredients` WRITE;
/*!40000 ALTER TABLE `purchases_has_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchases_has_liqueurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases_has_liqueurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `licor_id` int(10) unsigned NOT NULL,
  `compra_id` int(10) unsigned NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_has_liqueurs_licor_id_foreign` (`licor_id`),
  KEY `purchases_has_liqueurs_compra_id_foreign` (`compra_id`),
  CONSTRAINT `purchases_has_liqueurs_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchases_has_liqueurs_licor_id_foreign` FOREIGN KEY (`licor_id`) REFERENCES `liqueurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchases_has_liqueurs` WRITE;
/*!40000 ALTER TABLE `purchases_has_liqueurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases_has_liqueurs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `records_usuario_id_foreign` (`usuario_id`),
  CONSTRAINT `records_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;
/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `table_id` int(10) unsigned NOT NULL,
  `fecha_solicitud` date NOT NULL,
  `fecha_reservacion` date NOT NULL,
  `hora_reservacion` time NOT NULL,
  `especificacion` text COLLATE utf8_spanish_ci NOT NULL,
  `estatus` varchar(255) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'Sin confirmar',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservations_client_id_foreign` (`client_id`),
  KEY `reservations_table_id_foreign` (`table_id`),
  CONSTRAINT `reservations_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `reservations_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (1,11,1,'2016-09-30','2016-09-30','09:00:00','','Sin confirmar',NULL,NULL),(2,11,2,'2016-09-30','2016-09-30','09:00:00','','Sin confirmar',NULL,NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rol` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `abreviatura` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_rol_unique` (`rol`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SuperUsuario','SuperSU','Acceso a todos los módulos, con opción a ver, editar y eliminar.',1),(2,'Administrador','Admin','Gestión de usuarios, privilegios, auditoria, recuperación y restauración de base de datos.',2),(3,'Tipo 1','Usuario','Gestión de proveedores, clientes, facturación, empleados, nomina, con opción a ver, crear y  modificar.',3),(4,'Tipo 2','Usuario','Gestión de clientes y factura, con opción a registrar y visualizar.',4),(5,'Tipo 3','Usuario','Gestión de servicios, pedidos de los clientes.',5),(6,'Tipo 4','Usuario','Gestión de servicios, pedidos de los clientes.',6),(7,'Tipo 5','Usuario','Reservaciones de mesas.',7);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sauces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sauces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salsa` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sauces` WRITE;
/*!40000 ALTER TABLE `sauces` DISABLE KEYS */;
INSERT INTO `sauces` VALUES (1,'Napolitana',NULL,NULL),(2,'Boloñesa',NULL,NULL),(3,'Bechamel',NULL,NULL);
/*!40000 ALTER TABLE `sauces` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sauces_has_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sauces_has_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sauce_id` int(10) unsigned NOT NULL,
  `ingredient_id` int(10) unsigned NOT NULL,
  `cantidad_ingrediente` double(8,2) NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sauces_has_ingredients_sauce_id_foreign` (`sauce_id`),
  KEY `sauces_has_ingredients_ingredient_id_foreign` (`ingredient_id`),
  KEY `sauces_has_ingredients_unit_id_foreign` (`unit_id`),
  CONSTRAINT `sauces_has_ingredients_ingredient_id_foreign` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sauces_has_ingredients_sauce_id_foreign` FOREIGN KEY (`sauce_id`) REFERENCES `sauces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sauces_has_ingredients_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sauces_has_ingredients` WRITE;
/*!40000 ALTER TABLE `sauces_has_ingredients` DISABLE KEYS */;
INSERT INTO `sauces_has_ingredients` VALUES (1,1,1,100.00,2,NULL,NULL),(2,2,1,200.00,2,NULL,NULL),(3,3,1,300.00,2,NULL,NULL);
/*!40000 ALTER TABLE `sauces_has_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero_mesa` int(11) NOT NULL,
  `estatus` varchar(255) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'Disponible',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tables` WRITE;
/*!40000 ALTER TABLE `tables` DISABLE KEYS */;
INSERT INTO `tables` VALUES (1,1,'Disponible',NULL,NULL),(2,2,'Disponible',NULL,NULL),(3,3,'Disponible',NULL,NULL),(4,4,'Disponible',NULL,NULL),(5,5,'Disponible',NULL,NULL),(6,6,'Disponible',NULL,NULL),(7,7,'Disponible',NULL,NULL),(8,8,'Disponible',NULL,NULL),(9,9,'Disponible',NULL,NULL),(10,10,'Disponible',NULL,NULL),(11,11,'Disponible',NULL,NULL),(12,12,'Disponible',NULL,NULL);
/*!40000 ALTER TABLE `tables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `temporary_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporary_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `asignacion_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `temporary_assignments_empleado_id_foreign` (`empleado_id`),
  KEY `temporary_assignments_asignacion_id_foreign` (`asignacion_id`),
  CONSTRAINT `temporary_assignments_asignacion_id_foreign` FOREIGN KEY (`asignacion_id`) REFERENCES `others_assignments` (`id`),
  CONSTRAINT `temporary_assignments_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `temporary_assignments` WRITE;
/*!40000 ALTER TABLE `temporary_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_assignments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `temporary_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporary_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empleado_id` int(10) unsigned NOT NULL,
  `deduccion_id` int(10) unsigned NOT NULL,
  `estatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `temporary_deductions_empleado_id_foreign` (`empleado_id`),
  KEY `temporary_deductions_deduccion_id_foreign` (`deduccion_id`),
  CONSTRAINT `temporary_deductions_deduccion_id_foreign` FOREIGN KEY (`deduccion_id`) REFERENCES `others_deductions` (`id`),
  CONSTRAINT `temporary_deductions_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `temporary_deductions` WRITE;
/*!40000 ALTER TABLE `temporary_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `turns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `turns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `turno` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `hora_entrada` time NOT NULL,
  `hora_salida` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `turns_turno_unique` (`turno`),
  UNIQUE KEY `turns_hora_entrada_unique` (`hora_entrada`),
  UNIQUE KEY `turns_hora_salida_unique` (`hora_salida`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `turns` WRITE;
/*!40000 ALTER TABLE `turns` DISABLE KEYS */;
INSERT INTO `turns` VALUES (1,'Mañana','07:00:00','15:00:00',NULL,NULL),(2,'Noche','15:00:00','23:00:00',NULL,NULL);
/*!40000 ALTER TABLE `turns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unidad` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `units_unidad_unique` (`unidad`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (2,'G'),(1,'KG'),(3,'L'),(4,'ML');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roles_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `user` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_roles_id_foreign` (`roles_id`),
  CONSTRAINT `users_roles_id_foreign` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,7,'Magdalen','Antwan','$2y$10$2F1dTDpm8w8G5sAQ5iuG.uO049eyPS1IDDkCN9Mab.4WNtDy9o5tS','meta.kirlin@gmail.com',NULL,NULL,NULL),(2,7,'Mitchel','Bernita','$2y$10$0n2WjwJP7uxdI.rIgZDNN.kikUtm1KoHfGue0q2chA9B3Ln6DHS/m','beier.adolph@gmail.com',NULL,NULL,NULL),(3,7,'Rebekah','Frederick','$2y$10$IWrPBZDO893u077tQf7SU.U2ypNPuuoksO5/tDJfdOQ70iATRqd2S','dietrich.josephine@yahoo.com',NULL,NULL,NULL),(4,7,'Kelly','Tessie','$2y$10$9QThXKL6UuJOIX6b0JzgaOaHbIQdAXNwE/0QHtWm9h9/fuDDApRPe','gwill@yahoo.com',NULL,NULL,NULL),(5,7,'Tobin','Mackenzie','$2y$10$CrI8YCNHwjcGGW053iFKzOnG/RleWVDphqY.wJvMMqltm/BOFI5Ny','little.sandy@bernier.biz',NULL,NULL,NULL),(6,7,'Maeve','Stanley','$2y$10$Qm7vYYC14guFAIFNJCyjbOarmvIYAMHTJfs4g3WdGfXkdE2i9lx7u','francisca.mills@haley.com',NULL,NULL,NULL),(7,7,'Jayce','Brice','$2y$10$90S19rfG9WjRJUeUICplx.akdSbJ1oUyFTvdk6bUl7IJx4fhLbara','christopher88@yahoo.com',NULL,NULL,NULL),(8,7,'Savanna','Kirstin','$2y$10$dL6a/Tc2EQ6roksgYQeeuOXXV8I2mbTiBls7z7rkm67ZiR7iTvuSG','dejon.reynolds@ebert.com',NULL,NULL,NULL),(9,7,'Levi','Aaron','$2y$10$NuiV.jd80nwXkxYwKKWDr.F49yfNHrkteo5yVWIkZ5tijQStifZlG','deven06@gmail.com',NULL,NULL,NULL),(10,7,'Elyssa','Jaquelin','$2y$10$m/MGGHQYXAPFFwlnqhjvWOGJQIrPbQ5irJ65vKGN/Tm7NEhLEQfaK','tdouglas@yahoo.com',NULL,NULL,NULL),(11,7,'Ethelyn','Erik','$2y$10$zwmxz47Q.snwc8Xn6wxj9uDhlCrQBlpVt08790EVZdOVs5oS.0GPW','dooley.abdiel@blick.com',NULL,NULL,NULL),(12,7,'Gerardo','Rickie','$2y$10$SW.kCakXkmqRZz4euCAFnue8kYD/s2d3HAmevGXXG9EIr3pa6ndQe','wturner@ritchie.net',NULL,NULL,NULL),(13,7,'Carmelo','Jadon','$2y$10$QkRpoq1wL3vnkC9els4BXOeEpBcAmBjY2LUwCi0lupukW4Oo74Tqe','larkin.flavio@gmail.com',NULL,NULL,NULL),(14,7,'Eileen','Crystel','$2y$10$BlDcUqWkHWDef1si2TFJSO9Gtd0GrG8EyqJ1JTUGw0/2nWvy1o3pK','ike27@kerluke.com',NULL,NULL,NULL),(15,7,'Immanuel','Brook','$2y$10$QDLyvt5m4/KDyuKdmJxzHeoTHmY3gOhb5vlf82FLO4FZ.qUbXBW.i','damore.alex@bauch.org',NULL,NULL,NULL),(16,7,'Zakary','Tess','$2y$10$UxmG2Ph5qKWdcAGZmQPKFu43CXEuSZVxeJhkcfgWEtnNN6lCh4Uxm','runte.sid@boehm.com',NULL,NULL,NULL),(17,7,'Meredith','Jade','$2y$10$.M4yzTYt3kN46FVFx1lnOOGA5ieH4upCgWep7.WTL6efx.45WywI6','gaylord.ward@ratke.net',NULL,NULL,NULL),(18,7,'Annabelle','Leopold','$2y$10$6wchOlDu57G6Q66kC5Q37OHm8ishnDtQPu34t8mN30cde.BF.lm92','abshire.katrina@hotmail.com',NULL,NULL,NULL),(19,7,'Vinnie','Walker','$2y$10$H5Xiv/8XsU6npyyVOQahJOnthws6ewxpzHphJa3gLMtA81wb1CtcK','trent21@welch.com',NULL,NULL,NULL),(20,7,'Lina','Lilliana','$2y$10$lQ2hQWrxHnOEuMGuPX1Asuz7URPhLUVyyaH3ji9O/UhC6YSmemoxW','turcotte.adolfo@satterfield.net',NULL,NULL,NULL),(21,7,'Kaden','Beverly','$2y$10$RLAU/DUtTAzD/7VZxnhaGe68KJDI/2mV7aaxpkGnwJ./UYsJBsA22','fae.gleason@gmail.com',NULL,NULL,NULL),(22,7,'Cloyd','Rico','$2y$10$bDCPQ48iAdV4fpwT6wtSlOZCKciyk1jIpfpZCpobJdTk/luL6sqPG','schaefer.dessie@reynolds.com',NULL,NULL,NULL),(23,7,'Antwan','Alana','$2y$10$J7XWoRhwpvyLvoE4paMyou.idm.WN1a/s1BR23NF9/RDcJfYvpxhe','febert@yahoo.com',NULL,NULL,NULL),(24,7,'Brigitte','Richard','$2y$10$aqiTqXPWPiK1m8gJpUBoouZM3oq.4jukrAbJLMWDKrvmLpR1y7fcG','xdeckow@schoen.com',NULL,NULL,NULL),(25,7,'Mitchel','Diana','$2y$10$mablxkfs9Ilf5Z4o5QfPFO2ok3i5tHthfkojw5ZU1l2/7JwiQdEba','lue97@gmail.com',NULL,NULL,NULL),(26,7,'Emelie','Jamil','$2y$10$gJSAO9tZGNKzOdqc7p5.5OsgD/e0YuKAHFyPoVsXya8HhWxNQrhRy','missouri.cartwright@howell.biz',NULL,NULL,NULL),(27,7,'Joanie','Annalise','$2y$10$/qnvv5izI5siE2c1jH5Pauw5A3mebrRGFBJVT2bQvjxIzFuhTBkwC','carroll.brionna@howe.info',NULL,NULL,NULL),(28,7,'Charity','Earnestine','$2y$10$c4ZhsikMjFL5DwBgY227dOMRBdIOOwotQqYYSEyglt0QRpWNtAnGy','gust67@yahoo.com',NULL,NULL,NULL),(29,7,'Willa','Ken','$2y$10$EiiPaUx6w3AtMBUBoSBo.ubtnIiH6.nbzCod3O8zBBSZ/eIM6Xslm','lucinda31@yahoo.com',NULL,NULL,NULL),(30,7,'Randi','Madalyn','$2y$10$mdm/mjFXnlePEpMkdCed4uvGIjDtwJOLThO/3t0DBhZpQ6pKdkXMS','edna66@carroll.com',NULL,NULL,NULL),(31,1,'Saul','root','$2y$10$UQJHCh0DRtLbDoNEpWSgTekIzUZvdLhjgx5GF/jgP7P0hOZYDYeg2','sherzo-b@hotmail.com',NULL,NULL,NULL),(32,1,'Jesus','admin','$2y$10$i9TsPEKOHbohzXCz.yLtgOPV.qUXDHzdIdmqZ9Bx6j.JqC5L6l6We','mtr_1101@hotmail.com',NULL,NULL,NULL),(33,2,'Admin','Aministrador','$2y$10$c.c.PTFDupwD9zuuPBGpmO/HxNwLDNzhcmWubGwui6sh02cUHhvpG','sherzo-la@hotmail.com',NULL,NULL,NULL),(34,3,'Encargado','encargado','$2y$10$2ds5x48ai0C64uJU8.oJLOzyLfNd2pbcf6E8fqCLgu8AgRtg94Mlu','sherzo-p@hotmail.com',NULL,NULL,NULL),(35,4,'Cocinero','cocinero','$2y$10$0A90wqbzLt2CQN8J5mh5HOkBgNjWFpeN.vkaR1IJx.W.FxmZSlUni','sherzo-g@hotmail.com',NULL,NULL,NULL),(36,5,'Cajera','cajera','$2y$10$zhEF/pd60Bpq7LKrwMADKO6JTZscMpyrf7AQnyA/58.kblSlW17nm','sherzo-f@hotmail.com',NULL,NULL,NULL),(37,6,'Carlos','mesonero','$2y$10$Plgt27ja6aL4.j73jiI1oO5b7V1MRKECcLGjC1hlDiiTke.1G1QlS','sherzo-c@hotmail.com',NULL,NULL,NULL),(38,7,'Cliente','cliente','$2y$10$GT/iLiQLPybtQAdxDEv/t.3tE4Hn.YN1xh/TDwyqFs0XyOhzqYqQ.','sherzo-a@hotmail.com',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_modules_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_modules_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `module_action_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_modules_actions_user_id_foreign` (`user_id`),
  KEY `users_modules_actions_module_action_id_foreign` (`module_action_id`),
  CONSTRAINT `users_modules_actions_module_action_id_foreign` FOREIGN KEY (`module_action_id`) REFERENCES `modules_has_actions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_modules_actions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_modules_actions` WRITE;
/*!40000 ALTER TABLE `users_modules_actions` DISABLE KEYS */;
INSERT INTO `users_modules_actions` VALUES (1,31,1,NULL,NULL),(2,31,2,NULL,NULL),(3,31,3,NULL,NULL),(4,31,4,NULL,NULL),(5,31,5,NULL,NULL),(6,31,6,NULL,NULL),(7,31,7,NULL,NULL),(8,31,8,NULL,NULL),(9,31,9,NULL,NULL),(10,31,10,NULL,NULL),(11,31,11,NULL,NULL),(12,31,12,NULL,NULL),(13,31,13,NULL,NULL),(14,31,14,NULL,NULL),(15,31,15,NULL,NULL),(16,31,16,NULL,NULL),(17,31,17,NULL,NULL),(18,31,18,NULL,NULL),(19,31,19,NULL,NULL),(20,31,20,NULL,NULL),(21,31,21,NULL,NULL),(22,31,22,NULL,NULL),(23,31,23,NULL,NULL),(24,31,24,NULL,NULL),(25,31,25,NULL,NULL),(26,31,26,NULL,NULL),(27,31,27,NULL,NULL),(28,31,28,NULL,NULL),(29,31,29,NULL,NULL),(30,31,30,NULL,NULL),(31,31,31,NULL,NULL),(32,31,32,NULL,NULL),(33,31,33,NULL,NULL),(34,31,34,NULL,NULL),(35,31,35,NULL,NULL),(36,31,36,NULL,NULL),(37,31,37,NULL,NULL),(38,31,38,NULL,NULL),(39,31,39,NULL,NULL),(40,31,40,NULL,NULL),(41,31,41,NULL,NULL),(42,31,42,NULL,NULL),(43,31,43,NULL,NULL),(44,31,44,NULL,NULL),(45,31,45,NULL,NULL),(46,31,46,NULL,NULL),(47,31,47,NULL,NULL),(48,31,48,NULL,NULL),(49,31,49,NULL,NULL),(50,31,50,NULL,NULL),(51,31,51,NULL,NULL),(52,31,52,NULL,NULL),(53,31,53,NULL,NULL),(54,31,54,NULL,NULL),(55,31,55,NULL,NULL),(56,31,56,NULL,NULL),(57,31,57,NULL,NULL),(58,31,58,NULL,NULL),(59,31,59,NULL,NULL),(60,31,60,NULL,NULL),(61,31,61,NULL,NULL),(62,31,62,NULL,NULL),(63,31,63,NULL,NULL),(64,31,64,NULL,NULL),(65,31,65,NULL,NULL),(66,31,66,NULL,NULL),(67,31,67,NULL,NULL),(68,31,68,NULL,NULL),(69,31,69,NULL,NULL),(70,31,70,NULL,NULL),(71,31,71,NULL,NULL),(72,31,72,NULL,NULL),(73,31,73,NULL,NULL),(74,31,74,NULL,NULL),(75,31,75,NULL,NULL),(76,31,76,NULL,NULL),(77,31,77,NULL,NULL),(78,31,78,NULL,NULL),(79,31,79,NULL,NULL),(80,32,1,NULL,NULL),(81,32,2,NULL,NULL),(82,32,3,NULL,NULL),(83,32,4,NULL,NULL),(84,32,5,NULL,NULL),(85,32,6,NULL,NULL),(86,32,7,NULL,NULL),(87,32,8,NULL,NULL),(88,32,9,NULL,NULL),(89,32,10,NULL,NULL),(90,32,11,NULL,NULL),(91,32,12,NULL,NULL),(92,32,13,NULL,NULL),(93,32,14,NULL,NULL),(94,32,15,NULL,NULL),(95,32,16,NULL,NULL),(96,32,17,NULL,NULL),(97,32,18,NULL,NULL),(98,32,19,NULL,NULL),(99,32,20,NULL,NULL),(100,32,21,NULL,NULL),(101,32,22,NULL,NULL),(102,32,23,NULL,NULL),(103,32,24,NULL,NULL),(104,32,25,NULL,NULL),(105,32,26,NULL,NULL),(106,32,27,NULL,NULL),(107,32,28,NULL,NULL),(108,32,29,NULL,NULL),(109,32,30,NULL,NULL),(110,32,31,NULL,NULL),(111,32,32,NULL,NULL),(112,32,33,NULL,NULL),(113,32,34,NULL,NULL),(114,32,35,NULL,NULL),(115,32,36,NULL,NULL),(116,32,37,NULL,NULL),(117,32,38,NULL,NULL),(118,32,39,NULL,NULL),(119,32,40,NULL,NULL),(120,32,41,NULL,NULL),(121,32,42,NULL,NULL),(122,32,43,NULL,NULL),(123,32,44,NULL,NULL),(124,32,45,NULL,NULL),(125,32,46,NULL,NULL),(126,32,47,NULL,NULL),(127,32,48,NULL,NULL),(128,32,49,NULL,NULL),(129,32,50,NULL,NULL),(130,32,51,NULL,NULL),(131,32,52,NULL,NULL),(132,32,53,NULL,NULL),(133,32,54,NULL,NULL),(134,32,55,NULL,NULL),(135,32,56,NULL,NULL),(136,32,57,NULL,NULL),(137,32,58,NULL,NULL),(138,32,59,NULL,NULL),(139,32,60,NULL,NULL),(140,32,61,NULL,NULL),(141,32,62,NULL,NULL),(142,32,63,NULL,NULL),(143,32,64,NULL,NULL),(144,32,65,NULL,NULL),(145,32,66,NULL,NULL),(146,32,67,NULL,NULL),(147,32,68,NULL,NULL),(148,32,69,NULL,NULL),(149,32,70,NULL,NULL),(150,32,71,NULL,NULL),(151,32,72,NULL,NULL),(152,32,73,NULL,NULL),(153,32,74,NULL,NULL),(154,32,75,NULL,NULL),(155,32,76,NULL,NULL),(156,32,77,NULL,NULL),(157,32,78,NULL,NULL),(158,32,79,NULL,NULL),(159,33,73,NULL,NULL),(160,33,74,NULL,NULL),(161,33,75,NULL,NULL),(162,33,76,NULL,NULL),(163,33,77,NULL,NULL),(164,33,78,NULL,NULL),(165,33,79,NULL,NULL),(166,34,1,NULL,NULL),(167,34,2,NULL,NULL),(168,34,3,NULL,NULL),(169,34,4,NULL,NULL),(170,34,5,NULL,NULL),(171,34,6,NULL,NULL),(172,34,7,NULL,NULL),(173,34,8,NULL,NULL),(174,34,9,NULL,NULL),(175,34,10,NULL,NULL),(176,34,11,NULL,NULL),(177,34,12,NULL,NULL),(178,34,13,NULL,NULL),(179,34,14,NULL,NULL),(180,34,15,NULL,NULL),(181,34,16,NULL,NULL),(182,34,17,NULL,NULL),(183,34,18,NULL,NULL),(184,34,19,NULL,NULL),(185,34,20,NULL,NULL),(186,34,21,NULL,NULL),(187,34,22,NULL,NULL),(188,34,23,NULL,NULL),(189,34,24,NULL,NULL),(190,34,25,NULL,NULL),(191,34,26,NULL,NULL),(192,34,27,NULL,NULL),(193,34,28,NULL,NULL),(194,34,29,NULL,NULL),(195,34,30,NULL,NULL),(196,34,31,NULL,NULL),(197,34,32,NULL,NULL),(198,34,33,NULL,NULL),(199,34,34,NULL,NULL),(200,34,35,NULL,NULL),(201,34,36,NULL,NULL),(202,34,37,NULL,NULL),(203,34,38,NULL,NULL),(204,34,39,NULL,NULL),(205,34,40,NULL,NULL),(206,34,41,NULL,NULL),(207,34,42,NULL,NULL),(208,34,43,NULL,NULL),(209,34,44,NULL,NULL),(210,34,45,NULL,NULL),(211,34,46,NULL,NULL),(212,34,47,NULL,NULL),(213,34,48,NULL,NULL),(214,34,49,NULL,NULL),(215,34,50,NULL,NULL),(216,34,51,NULL,NULL),(217,34,52,NULL,NULL),(218,34,53,NULL,NULL),(219,34,54,NULL,NULL),(220,34,55,NULL,NULL),(221,34,56,NULL,NULL),(222,34,57,NULL,NULL),(223,34,58,NULL,NULL),(224,34,59,NULL,NULL),(225,34,60,NULL,NULL),(226,34,61,NULL,NULL),(227,34,62,NULL,NULL),(228,34,63,NULL,NULL),(229,34,64,NULL,NULL),(230,34,65,NULL,NULL),(231,34,66,NULL,NULL),(232,34,67,NULL,NULL),(233,34,68,NULL,NULL),(234,34,69,NULL,NULL),(235,34,70,NULL,NULL),(236,34,71,NULL,NULL),(237,34,72,NULL,NULL),(238,35,5,NULL,NULL),(239,35,6,NULL,NULL),(240,35,7,NULL,NULL),(241,35,8,NULL,NULL),(242,35,9,NULL,NULL),(243,35,10,NULL,NULL),(244,35,11,NULL,NULL),(245,35,12,NULL,NULL),(246,35,13,NULL,NULL),(247,35,14,NULL,NULL),(248,35,15,NULL,NULL),(249,35,16,NULL,NULL),(250,35,17,NULL,NULL),(251,35,18,NULL,NULL),(252,35,19,NULL,NULL),(253,35,20,NULL,NULL),(254,35,21,NULL,NULL),(255,36,1,NULL,NULL),(256,36,2,NULL,NULL),(257,36,3,NULL,NULL),(258,36,5,NULL,NULL),(259,36,9,NULL,NULL),(260,36,13,NULL,NULL),(261,36,17,NULL,NULL),(262,36,21,NULL,NULL),(263,36,24,NULL,NULL),(264,36,25,NULL,NULL),(265,37,5,NULL,NULL),(266,37,9,NULL,NULL),(267,37,13,NULL,NULL),(268,37,17,NULL,NULL),(269,37,21,NULL,NULL),(270,37,22,NULL,NULL),(271,37,23,NULL,NULL),(272,37,24,NULL,NULL);
/*!40000 ALTER TABLE `users_modules_actions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_vip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_vip_user_id_foreign` (`user_id`),
  KEY `users_vip_client_id_foreign` (`client_id`),
  CONSTRAINT `users_vip_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `users_vip_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_vip` WRITE;
/*!40000 ALTER TABLE `users_vip` DISABLE KEYS */;
INSERT INTO `users_vip` VALUES (1,37,13);
/*!40000 ALTER TABLE `users_vip` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

